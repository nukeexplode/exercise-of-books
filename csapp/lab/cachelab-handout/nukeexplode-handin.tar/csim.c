#include "cachelab.h"
#include <time.h>

typedef struct {
    unsigned vaild;
    unsigned tag;
    clock_t time_stamp;
}cache_line;

int main()
{
    
    printSummary(0, 0, 0);
    return 0;
}